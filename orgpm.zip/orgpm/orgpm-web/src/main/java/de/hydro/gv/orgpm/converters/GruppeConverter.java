package de.hydro.gv.orgpm.converters;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

import de.hydro.gv.orgpm.actions.Actions;
import de.hydro.gv.orgpm.actions.MitarbeiterAktionen;
import de.hydro.gv.orgpm.models.Mitarbeiter;

@FacesConverter(value = "GruppeConverter")
public class GruppeConverter implements Converter {
	
	@Inject
	private MitarbeiterAktionen actions;

	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {
		Integer id = Integer.parseInt(arg2);
		try {
			for (Mitarbeiter tempMA : actions.getAlleMitarbeiter())
				if(tempMA.getId().equals(id)) return tempMA;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {
		Mitarbeiter mitarbeiter = (Mitarbeiter) arg2;
		
		return mitarbeiter.getId().toString();
	}


}
